require 'awspec'
require 'awsecrets'
require 'aws-sdk-core'
require 'fileutils'

## --> Variables
$app_env = ENV['TF_VAR_ENVIRONMENT']
$app_name = ENV['TF_VAR_APPLICATION']
$aws_region = ENV['TF_VAR_AWS_REGION']
$aws_account_id = ENV['TF_VAR_AWS_ACCOUNT_ID']
$aws_s3_bucket = ENV['TF_VAR_TFSTATE_S3_BUCKET']
$tfstate_aws_region = ENV['TF_VAR_TFSTATE_AWS_REGION']
s3_credentials = Aws::InstanceProfileCredentials.new(retries: 3)
s3_client = s3 = Aws::S3::Client.new(region: "#{$tfstate_aws_region}", credentials: s3_credentials)
Awsecrets.load(secrets_path: File.expand_path('./secrets.yml', File.dirname(__FILE__)), region: "#{$aws_region}")

## --> Create directory structure
FileUtils.mkpath('tfstate_files/vpc')
#FileUtils.mkpath('tfstate_files/nat_gw')
#FileUtils.mkpath('tfstate_files/route_tables')

## --> Download tfstate file from AWS S3 bucket
vpc_tf_state_file = s3_client.get_object({bucket: "#{$aws_s3_bucket}", key:"#{$aws_account_id}/#{$aws_region}/#{$app_env}/#{$app_name}/vpc.tfstate"}, target: "./tfstate_files/vpc/vpc_tfstate.json")
