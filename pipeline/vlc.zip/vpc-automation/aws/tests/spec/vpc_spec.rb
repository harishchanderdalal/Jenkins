require 'spec_helper'

## --> Variables
$vpc_state_source_file = './tfstate_files/vpc/vpc_tfstate.json'
$vpc_state_output_file = './tfstate_files/vpc/vpc.txt'

## --> Capture data from source file to output file using jq
vpc_state_output  = `cat #{$vpc_state_source_file} | jq '.modules[].resources[].primary.id' | awk -F'"' '{print $2}' > #{$vpc_state_output_file}`

## --> Test cases
vpc=[]
subnet=[]
acl=[]
igw=[]

if File.zero?($vpc_state_output_file)
  puts "there is no content available in #{$vpc_state_output_file}"
else
  file = File.open($vpc_state_output_file, "r")
  file.each_line do |line|
    line = line.chomp.split("-")
    case line.first
      when "subnet"
        subnet.push(line.join("-"))
      when "acl"
        acl.push(line.join("-"))
      when "igw"
        igw.push(line.join("-"))
      when "vpc"
        vpc.push(line.join("-"))
      #else
      #  puts "Untracked Resoureces::test cases are not required for them"
    end
  end
end

describe vpc(vpc[0]) do
  it { should exist }
  it { should be_available }
end

subnet.each { |x|
  describe subnet(x) do
  it { should exist }
  it { should be_available }
end
}

describe internet_gateway(igw[0]) do
  it { should exist }
   it { should be_attached_to(vpc[0]) }
end

describe  network_acl(acl[0]) do
  it { should exist }
  its('vpc.id') { should eq vpc[0] }
end

FileUtils.remove_dir('tfstate_files')
