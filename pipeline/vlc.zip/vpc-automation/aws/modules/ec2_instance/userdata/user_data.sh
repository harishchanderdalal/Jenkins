#!/bin/bash

MOUNT_POINT_NAME=${mount_point_name}
DEVICE_NAME=${device_name}

echo "=====================>!!!! Starting mounting activity !!!!<========================"
echo "=====> Creating partition <====="
(echo c; echo u; echo p; echo n; echo p; echo 1; echo; echo; echo p; echo w) | fdisk $DEVICE_NAME
if [ $? -eq 0 ]
then
    echo "=====> Parition is created successfully <====="
    echo "=====> Formatting the created partition <====="
    mkfs.ext4 "$DEVICE_NAME"1 > /dev/null 2>&1
    if [ $? -eq 0 ]
    then
        echo "=====> Formatting is done <====="
        echo "=====> Creating mount point <====="
        if [ -d "$MOUNT_POINT_NAME" ]
        then
            echo "=====> Mount point is already available <====="
            echo "=====> Updating FSTAB file <====="
            echo ""$DEVICE_NAME"1 $MOUNT_POINT_NAME ext4 defaults 1 1" >> /etc/fstab
            if [ $? -eq 0 ]
            then
                echo "=====> FSTAB file is updated successfully <====="
                echo "=====> Mounting new partition <====="
                mount -a > /dev/null 2>&1
                if [ $? -eq 0 ]
                then
                    echo "=====> Mounting of new partition is done successfully <====="
                else
                    echo "=====> Mounting of new partition is not done <====="
                    exit 1
                fi
            else
                echo "=====> FSTAB file is not updated <====="
                exit 1
            fi
        else
            echo "=====> Mount point is not available <====="
            echo "=====> Creating mount point <====="
            mkdir $MOUNT_POINT_NAME
            if [ $? -eq 0 ]
            then
                echo "=====> Mount point is created successfully ======"
                echo "=====> Updating FSTAB file <====="
                echo ""$DEVICE_NAME"1 $MOUNT_POINT_NAME ext4 defaults 1 1" >> /etc/fstab
                if [ $? -eq 0 ]
                then
                    echo "=====> FSTAB file is updated successfully <====="
                    echo "=====> Mounting new partition <====="
                    mount -a > /dev/null 2>&1
                    if [ $? -eq 0 ]
                    then
                        echo "=====> Mounting of new partition is done successfully <====="
                    else
                        echo "=====> Mounting of new partition is not done <====="
                        exit 1
                    fi
                else
                    echo "=====> FSTAB file is not updated <====="
                    exit 1
                fi
            else
                echo "=====> Mount point is not created  ======"
                exit 1
            fi
        fi
    else
        echo "=====> Formatting is not done <====="
        exit 1
    fi
else
    echo "=====> Parition is not created  <====="
fi
echo "=====================!!!! Starting mounting activity !!!!========================"
